Projeto artigo técnico gerado por I.A.s

💻 Tecnologias utilizadas no projeto
ChatGPT - para título e conteúdo
Lexica.art - para gerar imagens
PowerPoint - Para formatação de banners e Layouts


COMO ENTREGAR SEU PROJETO:
- Crie um repositório no GitHub com os prompts que você utilizou na criação do projeto; ✅
- Salve nesse mesmo repositório as imagens geradas na construção do seu artigo;✅
- Coloque o link do seu artigo no README do seu GitHub;✅
https://web.dio.me/articles/css-basico-como-comecar-a-estilizar-suas-paginas-web?back=%2Farticles&open-modal=true&page=1&order=oldest
- Envie para gente o link do seu repositório. ✅
